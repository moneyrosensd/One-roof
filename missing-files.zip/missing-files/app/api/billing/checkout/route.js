import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { prisma } from "@/lib/prisma";
import Stripe from "stripe";
import { NextResponse } from "next/server";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Called when the user clicks "Add payment method" — NOT at signup.
// This is the only point in the whole app that ever asks for a card.
export async function POST() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not logged in" }, { status: 401 });

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });

  let customerId = user.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe.customers.create({ email: user.email, name: user.name });
    customerId = customer.id;
    await prisma.user.update({ where: { id: user.id }, data: { stripeCustomerId: customerId } });
  }

  const checkoutSession = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
    success_url: `${process.env.NEXTAUTH_URL}/store?billing=success`,
    cancel_url: `${process.env.NEXTAUTH_URL}/store?billing=cancelled`,
    // If they still have trial days left when they choose to add a card early,
    // honor the remaining days instead of charging immediately.
    subscription_data: user.trialEndsAt && new Date(user.trialEndsAt) > new Date()
      ? { trial_end: Math.floor(new Date(user.trialEndsAt).getTime() / 1000) }
      : undefined,
  });

  return NextResponse.json({ url: checkoutSession.url });
}

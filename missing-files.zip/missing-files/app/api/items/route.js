import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { prisma } from "@/lib/prisma";
import { hasActiveAccess } from "@/lib/access";
import { NextResponse } from "next/server";

// GET: every item from every store, newest first — this is the real Browse feed
export async function GET() {
  const items = await prisma.item.findMany({
    include: { store: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ items });
}

// POST: bulk-create items on the logged-in user's own store — supports
// posting a whole batch at once, not one at a time
export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not logged in" }, { status: 401 });

  const dbUser = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!hasActiveAccess(dbUser)) {
    return NextResponse.json(
      { error: "Your free trial has ended. Add a payment method to keep posting.", code: "TRIAL_ENDED" },
      { status: 402 }
    );
  }

  const store = await prisma.store.findUnique({ where: { userId: session.user.id } });
  if (!store) return NextResponse.json({ error: "Set up your store first" }, { status: 400 });

  const { items } = await req.json(); // [{title, description, price, category, images}]
  if (!Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "No items provided" }, { status: 400 });
  }

  const created = await prisma.item.createMany({
    data: items.map((it) => ({
      storeId: store.id,
      title: it.title,
      description: it.description || "",
      price: it.price ?? null,
      category: it.category || "Other",
      images: it.images || [],
    })),
  });

  return NextResponse.json({ count: created.count });
}


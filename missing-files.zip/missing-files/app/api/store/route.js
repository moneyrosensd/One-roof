import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// GET: fetch the logged-in user's own store (or null if they haven't set one up)
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not logged in" }, { status: 401 });

  const store = await prisma.store.findUnique({ where: { userId: session.user.id } });
  return NextResponse.json({ store });
}

// POST: create or update the logged-in user's store
export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not logged in" }, { status: 401 });

  const body = await req.json();
  const { label, tagline, bgColor, profilePic, coverPhoto, lat, lng, statusText } = body;

  const data = {
    label,
    tagline,
    bgColor,
    profilePic,
    coverPhoto,
    lat,
    lng,
  };
  // Only touch the quote-of-the-day fields if one was actually sent
  if (statusText !== undefined) {
    data.statusText = statusText;
    data.statusSetAt = new Date();
  }

  const store = await prisma.store.upsert({
    where: { userId: session.user.id },
    update: data,
    create: { ...data, userId: session.user.id },
  });

  return NextResponse.json({ store });
}

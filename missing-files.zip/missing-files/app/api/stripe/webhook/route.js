import { prisma } from "@/lib/prisma";
import Stripe from "stripe";
import { NextResponse } from "next/server";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function POST(req) {
  const body = await req.text();
  const sig = req.headers.get("stripe-signature");

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return NextResponse.json({ error: `Webhook signature failed: ${err.message}` }, { status: 400 });
  }

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object;
      const subscription = await stripe.subscriptions.retrieve(session.subscription);
      await prisma.user.update({
        where: { stripeCustomerId: session.customer },
        data: { stripeSubscriptionId: subscription.id, subscriptionStatus: subscription.status },
      });
      break;
    }
    case "customer.subscription.updated":
    case "customer.subscription.deleted": {
      const subscription = event.data.object;
      await prisma.user.updateMany({
        where: { stripeCustomerId: subscription.customer },
        data: { subscriptionStatus: subscription.status }, // "active" | "past_due" | "canceled" | "trialing"
      });
      break;
    }
    default:
      break; // ignore events we don't care about
  }

  return NextResponse.json({ received: true });
}

// Stripe needs the raw request body to verify the signature — this tells
// Next.js not to parse it as JSON first.
export const config = { api: { bodyParser: false } };

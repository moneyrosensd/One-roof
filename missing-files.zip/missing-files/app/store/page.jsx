import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import TrialBanner from "@/components/TrialBanner";
import { daysLeftInTrial } from "@/lib/access";

export default async function StorePage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  const store = await prisma.store.findUnique({ where: { userId: session.user.id } });
  const items = await prisma.item.findMany({ orderBy: { createdAt: "desc" }, take: 50 });

  return (
    <main style={{ padding: 24, fontFamily: "sans-serif" }}>
      <TrialBanner subscriptionStatus={user.subscriptionStatus} trialDaysLeft={daysLeftInTrial(user)} />

      <h1>One Roof</h1>
      <p>Signed in as {session.user.email || session.user.name}</p>

      {store ? (
        <p>Your page: <strong>{store.label}</strong></p>
      ) : (
        <p>
          You haven't set up your page yet. This is a placeholder — the full
          page-setup flow, browse feed, cart, messaging, and auction UI from
          the prototype still need to be ported into this project as real
          components wired to the database.
        </p>
      )}

      <h2>Recent items across all pages</h2>
      <ul>
        {items.map((it) => (
          <li key={it.id}>
            {it.title} — {it.price === null ? "Free" : `$${it.price}`} ({it.category})
          </li>
        ))}
      </ul>
    </main>
  );
}

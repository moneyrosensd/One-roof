# One Roof — real login setup

This gives your app **real** accounts: Facebook login and email magic links,
both persisted in a real database. Here's exactly what to do with it.

## 1. Create the database
- Sign up for [Supabase](https://supabase.com) (free tier is fine) or Neon/Railway.
- Copy the Postgres connection string into `DATABASE_URL` in `.env`.
- Run:
  ```
  npm install
  npx prisma migrate dev --name init
  ```

## 2. Set up real Facebook Login
1. Go to [developers.facebook.com](https://developers.facebook.com) → **My Apps** → **Create App** → choose "Consumer".
2. Inside the app, add the **Facebook Login** product.
3. Under Facebook Login → Settings, add this to "Valid OAuth Redirect URIs":
   `https://yourdomain.com/api/auth/callback/facebook`
4. Under Settings → Basic, copy the **App ID** and **App Secret** into `.env`.
5. While the app is in "Development Mode," only you and people you add as
   testers can log in. To let the public log in, submit the app for
   Facebook's **App Review** (usually needs a privacy policy page and a
   short screen-recording of the login flow).

## 3. Set up email magic links
1. Sign up for [Resend](https://resend.com) (or any SMTP provider).
2. Verify a sending domain (or use their test domain while developing).
3. Put the API key and sender address into `.env` as shown in `.env.example`.

## 4. Generate a NextAuth secret
```
openssl rand -base64 32
```
Put the result in `NEXTAUTH_SECRET`.

## 5. Run it locally
```
npm install
npm run dev
```
Visit `http://localhost:3000/login` — both login buttons will actually work
against your real Facebook app and real email provider once the `.env`
values are filled in.

## 6. Deploy it for real
- Push this to GitHub.
- Import the repo into [Vercel](https://vercel.com).
- Add all the same `.env` values in Vercel's Project Settings → Environment Variables.
- Update `NEXTAUTH_URL` and the Facebook redirect URI to your real production domain.

## 7. Set up billing (30-day free trial, no card upfront)
1. Create a [Stripe](https://stripe.com) account.
2. Dashboard → Products → create a product like "One Roof — Seller Plan" with a
   monthly recurring price. Copy its Price ID into `STRIPE_PRICE_ID`.
3. Dashboard → Developers → API keys → copy the secret key into `STRIPE_SECRET_KEY`.
4. Dashboard → Developers → Webhooks → add endpoint:
   `https://yourdomain.com/api/stripe/webhook`, listening for
   `checkout.session.completed`, `customer.subscription.updated`,
   `customer.subscription.deleted`. Copy the signing secret into `STRIPE_WEBHOOK_SECRET`.
5. That's it — nobody sees a card form until they choose to (or their 30-day
   trial genuinely runs out and they want to keep posting). The trial starts
   automatically the moment someone signs up, no Stripe customer created yet.

## Launch checklist — things that matter before real strangers use this
- **Privacy Policy & Terms of Service pages.** Required by Facebook's App
  Review and by Stripe before you can accept live payments. Keep them
  genuinely accurate to what your app does (location use, messaging, data
  stored).
- **Real image uploads**, not just pasted URLs. Add
  [UploadThing](https://uploadthing.com) or S3 so sellers can upload photos
  directly from their phone instead of needing an image already hosted
  somewhere.
- **Content moderation.** Even a simple "Report item" / "Report user" button
  plus a manual review queue goes a long way before this is public — local
  marketplaces attract scams and prohibited listings fast.
- **Rate limiting** on posting and messaging (e.g. via
  [Upstash](https://upstash.com)) so one account can't spam the feed.
- **Facebook App Review.** Until your Facebook app passes review, only you
  and testers you manually add can use Facebook login — plan for this before
  a public launch date.
- **A way to actually reach sellers if something goes wrong** — a support
  email at minimum.


## What's actually real here vs. the earlier prototype
- Accounts and sessions persist in a real database — no more losing your
  login on refresh.
- Facebook login goes through Facebook's real OAuth flow once your app is
  approved.
- Magic link emails are real emails, sent through your provider.
- The `Store` and `Item` tables replace the shared in-memory storage from
  the prototype, so each person's data is properly tied to their account.

## What I didn't build here
- The rest of the app (browse feed, item cards, messaging, AI pricing) —
  I can port that UI over from the prototype artifact into this Next.js
  project next, wired to these real tables, if you want.

## 8. Get a real installable app fast — no App Store wait
This project is now a PWA (Progressive Web App). Once deployed to Vercel:
1. Visit the site on an iPhone in Safari → Share → **Add to Home Screen**.
2. Visit it on Android in Chrome → menu → **Install app** (or **Add to Home screen**).
3. It now behaves like a real app: its own icon, full-screen, works from the
   home screen — no Apple/Google review needed for this step.
4. You still need real icon files at `/public/icon-192.png`,
   `/public/icon-512.png`, and `/public/icon-512-maskable.png` — export your
   logo at those sizes and drop them in.

## 9. Go fully native on both app stores
Once the web version is live and working:
1. Install [Capacitor](https://capacitorjs.com): `npm install @capacitor/core @capacitor/cli`, then `npx cap init`.
2. `npx cap add ios` and `npx cap add android` — this generates real Xcode and Android Studio projects wrapping your live site.
3. **Apple**: join the [Apple Developer Program](https://developer.apple.com/programs/) ($99/yr), open the iOS project in Xcode (needs a Mac), and submit through App Store Connect.
   - Guideline 1.2 (User Generated Content): you must have report/block tools — the trust & review system already covers this.
   - Guideline 4.2 (Minimum Functionality): add at least one native-feeling touch (push notifications for new messages/bids is the natural one here).
4. **Google Play**: create a [Play Console](https://play.google.com/console) account ($25 one-time), open the Android project in Android Studio, and submit.
   - Fill out the Data Safety form honestly (location, messages, photos are all collected).
   - Their User Generated Content policy has the same report/block expectation as Apple's.
5. Both stores will also want a **privacy policy URL** and **support contact** — host a simple privacy policy page on the same Vercel deployment.
